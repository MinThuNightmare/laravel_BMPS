<?php $__env->startSection('intocode'); ?>

<div class="container-fluid ">
    <div class="container pt-5">
        <div class="row">
            <div class="col-12">
                <div class="post_link d-flex justify-content-end mb-3">
                    <a class="btn btn-sm btn-outline-info" href="<?php echo e(url('posts/create')); ?>">Create Post</a>
                </div>
                <table class="table table-bordered table-hover ">
                    <thead class="text-center">
                        <tr>
                            <th>id</th>
                            <th>Title</th>
                            <th>Image</th>
                            <th>Content</th>
                            <th>Edit / Delete</th>
                        </tr>
                    </thead>
                    <tbody >
                        <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($data->id); ?></td>
                                <td><?php echo e($data->title); ?></td>
                                <td><?php echo e($data->img); ?></td>
                                <td><?php echo e($data->content); ?></td>
                                <td>
                                    <div class="d-flex">
                                        <a class="text-decoration-none me-2" href="<?php echo e(url('posts/'.$data->id.'/edit')); ?>">
                                            <button class="btn btn-sm btn-outline-info">Edit</button>
                                        </a>
                                        <form action="<?php echo e(url('posts/'.$data->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="btn btn-sm btn-outline-danger">Delete</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('posts.introcode', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\MEGAsync\BMPS\Laravel\crud\resources\views/posts/post.blade.php ENDPATH**/ ?>