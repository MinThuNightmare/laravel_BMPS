<?php $__env->startSection('intocode'); ?>

    <div class="container-fluid ">
        <div class="container mt-5">
            <div class="row">
                <div class="col-3"></div>
                <div class="col-6">
                    <h3 class="text-info">Edit Post</h3>
                    <div class="post_link d-flex justify-content-end">
                        <a href="<?php echo e(url('posts')); ?>" class="btn btn-sm btn-outline-success">View Posts</a>
                    </div>
                    <form action="<?php echo e(url('posts/'.$editdata->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group">
                            <label class="mt-3 text-black-50" for="title">Post Title</label>
                            <input class="form-control" type="text" id="title" name="title" placeholder="Post Title" value="<?php echo e($editdata->title ?? old('content')); ?>">

                            <label class="mt-3 text-black-50" for="img">Post Imgae</label>
                            <input class="form-control" type="text" id="img" name="img" placeholder="Your Image" value="<?php echo e($editdata->img ?? old('img')); ?>">

                            <label class="mt-3 text-black-50" for="content">Your Post</label>
                            <textarea class="form-control" placeholder="What is in Your Mind..." name="content" id="content" cols="30" rows="3"><?php echo e($editdata->content ?? old('content')); ?></textarea>

                            <button class="mt-3 btn btn-sm btn-outline-info">Edit</button>
                        </div>
                    </form>
                </div>
                <div class="col-3"></div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('posts.introcode', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\MEGAsync\BMPS\Laravel\crud\resources\views/posts/edit.blade.php ENDPATH**/ ?>