<?php $__env->startSection('intocode'); ?>

    <div class="container-fluid ">
        <div class="container mt-5">
            <div class="row">
                <div class="col-3"></div>
                <div class="col-6">
                    <h3 class="text-info">Upload Post</h3>
                    <div class="post_link d-flex justify-content-end">
                        <a href="<?php echo e(url('posts')); ?>" class="btn btn-sm btn-outline-success">View Posts</a>
                    </div>
                    <form action="<?php echo e(url('posts')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label class="mt-3 text-black-50" for="title">Post Title</label>
                            <input class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" id="title" name="title" placeholder="Post Title" value="<?php echo e(old('content')); ?>">

                            <label class="mt-3 text-black-50" for="img">Post Imgae</label>
                            <input class="form-control <?php $__errorArgs = ['img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" id="img" name="img" placeholder="Your Image" value="<?php echo e(old('content')); ?>">

                            <label class="mt-3 text-black-50" for="content">Your Post</label>
                            <textarea class="form-control <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="What is in Your Mind..." name="content" id="content" cols="30" rows="3"><?php echo e(old('content')); ?></textarea>

                            <button class="mt-3 btn btn-sm btn-outline-info">Upload</button>
                        </div>
                    </form>
                </div>
                <div class="col-3"></div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('posts.introcode', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\MEGAsync\BMPS\Laravel\crud\resources\views/posts/create.blade.php ENDPATH**/ ?>